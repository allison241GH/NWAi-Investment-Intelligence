# The Agent-Era Readiness Framework for NWAi Investment Analysis

*The third always-active investing lens, alongside Structural Discontinuity and Memory Lock-in.*
*Derived from: `docs/strategy/future-of-venture-investing/NWAi-Agent-Era-Readiness-Thesis-2026-06.md`.*

## The Core Challenge: The Dissolving-Problem Paradox

AI agents are becoming the new substrate through which problems get solved — across work, the firm,
commerce, and ultimately every domain of economic and social life. The agent-first internet
(bots crossed 57.5% of web traffic in mid-2026, ~1,000:1 bot:human page-loads) is only the
first-visible *edge* of a far larger shift: the agent is becoming the predominant **actor** and
predominant **consumer** of digital products, information, and transactions.

This creates a durability trap that the AI Moats and Structural Discontinuity lenses do not catch:

- A startup can have a genuinely **excellent solution to a problem that agents are about to
  reimagine, dissolve, or transform.** The better the design, the more dangerous the bet — polish
  hides the rot.
- **The test is NOT "is it built for humans or for agents."** That is a shallow interface question
  (does it have an `llms.txt`, an API, a markdown mirror). The real test operates one level deeper:
  *does a future of capable agents reshape the very problem this company solves — and is the
  founder building for that, or for the world as it exists today?*

The screening **doorway question** — the entry point, not the whole test:

> **"Is this information for a human to act on, or a transaction for an agent to complete?"**

For a human, information is an *asset to act on*. For an agent, it is a *transaction to complete*.
A company that has not reckoned with the fact that most of its "users" may soon be machines —
acting for humans, at 1,000× the volume, with none of the engagement its model assumes — has a
durability problem it probably cannot see. Walk through the doorway and the scored questions are:
*Which problems do agents dissolve? Which do they amplify? Which become newly valuable precisely
because agents exist?*

---

## The Three Test Dimensions

Each dimension is scored **0–5** (anchors below). Apply both horizons: score **durable-now**
(2–3 yr, underwritable today) *and* **visionary-for-what's-coming** (decade-out arc). Note the gap
between the two — a company that scores well now but poorly on the arc is renting its durability.

### Dimension 1: Problem Reimagination

*Does the founder solve the problem as agents will reshape it, or as it exists today?*

The single most important discrimination in this framework. A founder who *sees* the shift builds
for the reimagined problem; one who does not builds a beautiful answer to a question agents stop
asking. (Worked example: a comparison-shopping site is an excellent answer to "a human needs to
compare and decide" — but agents dissolve that problem by comparing and transacting directly. The
durable founder builds a structured offer-and-transaction layer agents call, priced on completed
transactions, not eyeballs. Same domain, reimagined problem.)

**Key question:** *If capable agents are doing the work in 3–5 years, is the problem this company
solves still being asked in the same form — and has the founder designed for the answer, not just
named the trend?*

**Investor Signals:**
- ✅ Founder can articulate, unprompted, how agents change the *problem* (not just "we use AI")
- ✅ The solution assumes an agent-mediated world — it gets *more* relevant as agents proliferate
- ✅ Evidence the founder is building for the reimagined problem, not retrofitting AI onto the old one
- ❌ A polished solution to a present-day, human-shaped problem with no reckoning with the shift
- ❌ "AI-powered" framing layered on a workflow agents will own outright (a Threatened company in
  Riding's clothes)
- ❌ The problem the product solves is one a personal agent will absorb as a built-in capability

### Dimension 2: Position in the Agent Economy

*Where does value land, and does the business model survive when agents are the actor and consumer?*

This is the work/firm and commerce/markets axis made concrete. Two failure modes dominate: a
**revenue model priced for humans** (per-seat, ad/engagement-funded) and a **cost model priced for
humans** (margins that assume human-scale traffic, exposed to the ~1,000:1 load asymmetry).

**Key question:** *When the buyer is a program and the worker is an agent, does this company still
have a customer, a billing unit, and a margin?*

**Investor Signals:**
- ✅ Captures value at the **completed transaction / outcome**, not the human view or seat
  (proof: Sierra's outcome-based pricing — charges only when the agent *resolves* the problem,
  escalations free; "why pay for a job well done rather than for the privilege of using software?")
- ✅ Sells to the **director-and-fleet**, not the vanishing human seat; or *is* the agent infrastructure
- ✅ **Callable by agents** and monetized on agent consumption; cost structure survives machine-volume traffic
- ✅ Agent-native cost structure; founder understands cost-per-task vs cost-per-seat economics
- ❌ **Per-seat revenue model** — the billing unit is evaporating as agents replace seats
- ❌ Ad- or engagement-funded; depends on human-funnel persuasion (ads, SEO, brand affect)
- ❌ Margin assumes human-scale traffic; the 1,000:1 bot load opens a cost-revenue scissors
- ❌ Operating plan scales **headcount linearly with revenue** (headcount as liability, not asset)
- ❌ "Stay off my lawn" bot-blocking as the entire strategy — a slow bleed of relevance

### Dimension 3: Agent-Era Moat

*What stays defensible when agents can scrape, ingest, and replicate the surface?*

This dimension shakes hands with the AI Moats and Memory Lock-in lenses, but asks the agent-era
version: when generation is cheap and surfaces are ingestible, the moat must rest on something
agents cannot route around. Bret Taylor's incumbent-side framing: when the marginal cost of
*generating* software falls toward zero, what a customer buys is no longer the code — it is "the
audit, the checks, the bugs other clients found and fixed." **Value migrates from production to
trust.**

**Key question:** *If an agent could scrape and reproduce this company's entire surface tomorrow,
what would remain that is genuinely hard to replicate?*

**Investor Signals:**
- ✅ **Un-scrapable value** — physical services, high-trust human relationships, local embeddedness
- ✅ **Proprietary flywheel that compounds under agent load** — gets richer, not cheaper, as machine usage scales
- ✅ **Transactional plumbing / supply position** — paid when an agent acts, owns the rails or the source
- ✅ **Human-verification & authenticity** — verified-human presence as a premium in a machine-saturated ecosystem
- ✅ **Governance of memory / data sovereignty** — user owns/controls/can delete agent memory
  (proof: OpenClaw stores memory as plain files you own, back up, or delete — local-first by default)
- ✅ **Accumulated institutional trust** — the hardened audit/validation no agent can mint overnight
- ❌ Value is fully ingestible — an agent could reproduce the surface in <48 hours (agent-era thin-wrapper)
- ❌ Moat is UX polish or aggregated public content agents replicate or route around
- ❌ Open-source-commoditizable with no proprietary data, trust, or workflow layer beneath it

---

## The Four-Posture Classification

Every company stands somewhere relative to the substrate shift. Name the posture — it is half the
verdict and maps cleanly to invest/pass logic. The core discrimination: a company **Riding** the
shift vs. one **Threatened** by it but telling a Riding story.

| Posture | Definition | Investment implication |
|---|---|---|
| **Threatened** | Agents reimagine or dissolve the problem this company solves. Excellent solution for a world that is ending. | ❌ Default toward **pass** unless a credible, funded path to Riding/Enabling exists. Good design makes this *more* dangerous — it hides the rot. |
| **Riding** | The company *is* the reimagined solution — it solves the problem as agents reshape it. | ✅ The prize. Where visionary durability lives. Verify it is real, not narrated. |
| **Enabling** | Picks-and-shovels for the agent economy — infrastructure, plumbing, verification, the rails agents run on. | ✅ Often the most underwritable bet of all — sells into the shift regardless of which application-layer winners emerge. |
| **Insulated** | Genuinely un-disruptable value — physical, high-trust, human-verified, locally embedded. The shift routes around it. | ✅ Durable, but **stress-test the claim hard.** Most "Insulated" companies are actually Threatened and don't know it. |

**Mixed posture is the common case — name the primary posture *and* the path.** Most real deals are
not purely one posture. A company can be **Threatened in its product** while holding **latent
Enabling or Insulated assets** that are real but unproven, unfunded, or unreserved (e.g. a
commoditizing technical surface sitting on top of a not-yet-contracted distribution channel, or an
accountability/trust function the founder treats as marketing rather than underwriting). When this
happens: assign the **primary posture from where the company actually is today** (usually the
weaker, product-level reality — do not let a latent asset launder a Threatened deal into a Riding
story), then **name the specific path** from that posture to the better one and **what must become
true** to walk it (the channel gets contracted; the trust function gets reserved/underwritten; the
flywheel dataset gets built). Naming the path *and its trigger* is the actionable output — it
converts the verdict into a watch condition or a deal-structure lever, not just a label.

---

## The Domain-Transformation Map

Reference context for *how* agents reshape the domain a deal operates in. Work/firm and
commerce/markets are first-class (deepest, most diligence-relevant); personal/society and
physical/cognitive are supporting. Use to locate a deal and read its durable-vs-exposed tells —
not as a per-domain rubric.

| Domain | How agents reimagine it | Durable signals (✅) | Exposed signals (❌) |
|---|---|---|---|
| **Work, the firm & economic structure** *(primary)* | Unit of production flips human-hour → agent-task; manager-of-agents org; seat→outcome pricing; agent-native firms do 1,000-person work with 10 people | Outcome/usage pricing; agent-native cost base; sells to directors+fleets; *is* the agent infrastructure | Per-seat revenue; headcount-linear opex; value prop = "makes a human doer 20% faster" at a task agents will own |
| **Commerce & markets** *(primary)* | Agent becomes the buyer; human funnel collapses; agent-to-agent transactions; disintermediation of the attention-middle; value re-concentrates at transaction & supply | Captures value at the transaction; plumbing/supply position; callable by agents; cost survives machine volume | Ad/engagement-funded; human-funnel persuasion; margin assumes human traffic; bot-blocking as strategy |
| **Personal life & delegation** *(supporting)* | Personal agents handle life-admin & purchasing; consumer relationship mediated through the agent, not the screen; attention economy erodes | Becomes the agent or the thing the agent reliably selects; owns a trusted user relationship | Competes for human attention/time; assumes the human browses and chooses directly |
| **Institutions, society & trust** *(supporting)* | Dead-internet dynamics; verified-human presence becomes a premium; provenance & authenticity load-bearing | Human-verification, provenance, authenticity layers; trust infrastructure | Generates undifferentiated AI "slop"; no provenance or human-verification angle |
| **Physical world & embodiment** *(supporting)* | Agents reach into atoms; intelligent/physical infrastructure; robotics; the agent-economy backbone | Un-scrapable physical value; intelligent infrastructure; the rails, not the ride | Pure-digital surface agents fully ingest; no physical or trust anchor |
| **Cognition & governance of memory** *(supporting)* | Agents remember & connect everything → inverse market for forgetting; memory governance | User-governed memory; data sovereignty; context expiration / right to forget | Platform hoards memory with no user governance; commoditizable data layer |

---

## Application to NWA Investment Analysis

When applying this lens at Screen (doorway + posture read), Scout (scored), or Diligence (full
scored sub-rubric):

1. **Doorway question first** — *information for a human to act on, or a transaction for an agent to
   complete?* Use it to orient before scoring.
2. **Score the three dimensions 0–5** — Problem Reimagination, Position in the Agent Economy,
   Agent-Era Moat. Score each on **both horizons** (durable-now / visionary-for-coming) and note the gap.
3. **Classify the posture** — Threatened / Riding / Enabling / Insulated, with one sentence of why.
4. **Apply flag triggers** (below) before finalizing.
5. **Headline verdict** — map the dimension total (0–15) to a single word for IC framing.

**0–5 dimension anchors:**
- **5** — Actively building for the reimagined problem; agents make the company *stronger*; clear durable moat
- **4** — Well-positioned and aware; minor exposure
- **3** — Partially positioned; aware of the shift but solution not yet reshaped for it
- **2** — Largely solving today's problem; meaningful exposure; weak or no agent-era moat
- **1** — Solving a problem agents are actively dissolving; no reckoning
- **0** — Directly in the path of dissolution with a model that cannot survive it

**Headline verdict (sum of three dimensions, 0–15):**
- **REIMAGINING (12–15)** — building for the world that is arriving; visionary + durable
- **ADAPTING (8–11)** — aware and partially positioned; durable near-term, arc unproven
- **EXPOSED (4–7)** — solving today's problem; vulnerable as the shift advances
- **BLIND (0–3)** — no reckoning with the substrate shift; beautiful solution to a dissolving problem

**Flag triggers:**
- ⚠️ **Yellow Flag** — solving a problem agents are likely to dissolve **within the hold period
  (~5 yr)**. State the dissolution mechanism and timeframe.
- ⚠️ **Yellow Flag** — **per-seat or ad/engagement revenue model** with no credible outcome/usage
  path. The billing unit is evaporating.
- ⚠️ **Strong Yellow Flag** — value proposition is fully **ingestible by an agent in <48 hours**
  (the agent-era thin-wrapper). Requires explicit moat justification to advance.
- ❌ **Red Flag** — **Threatened posture with no credible, funded path to Riding or Enabling.**
  Default to pass; the quality of the present-day solution is not a mitigant.

**Output format (for Scout / DD Report / Memo):**
> **Agent-Era Readiness: [REIMAGINING / ADAPTING / EXPOSED / BLIND]** — Posture: [Threatened /
> Riding / Enabling / Insulated]
> Problem Reimagination [X/5] · Position in the Agent Economy [X/5] · Agent-Era Moat [X/5] →
> [total]/15 (durable-now [n] / visionary-arc [n])
> *2–3 sentence rationale: what agents do to this problem, where the company stands, and the one
> thing that must be true for the posture to hold.*

---

## The Resonating Takeaway (for memos)

*"For a human, information is an asset to act on. For an agent, it is a transaction to complete. The
internet crossed over to the machines a year ahead of schedule, and the rest of the economy — work,
the firm, commerce — is next. The question is no longer whether a startup has a good answer; it is
whether the question its product answers will still be asked once the agents arrive. Back the
founders building for the reimagined problem. The ones with the most beautiful solution to a
dissolving problem are the most dangerous bets on the table."*

Use this framing when presenting the Agent-Era Readiness verdict to NWA's Investment Committee.
